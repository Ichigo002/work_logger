<?php 
    $fail = get("stt", "null");
?>